# FUTURES ANTÉRIEURS

*Le corps du simulacre, ou les deux métabolismes*

<!--
ÉTAT (à tenir à jour)
- VERROUILLÉ : l'architecture (00), le pari (2e principe = futur antérieur), le modulor (corps & chaleur, vertical), les super-noms (à confirmer par Cal).
- BROUILLON : l'Intro ci-dessous (ton approuvé plus tôt — à relire au regard du registre Kubernân). Le Seuil (rédigé, À RE-TONER Kubernân : couper les apartés au lecteur, durcir).
- À ÉCRIRE : Bif. I → IV + coda, bifurcation par bifurcation, au registre Kubernân (voir 01_STYLE_METHODE), en puisant dans les MATIERE_*.
- EN ATTENTE : encyclique de Léon XIV (II.6) ; « teilster » ; chiffres exacts à revérifier au moment d'écrire.
RAPPEL : figure, jamais recette (voir 04_GARDE_FOUS), surtout Bif. III.
-->

---

## Intro  <!-- verrouillée (ton approuvé) — relire vs registre Kubernân -->

Trois textes ont précédé celui-ci. L'un nommait le simulacre — le spectacle devenu monde, le réel remplacé par son image. Un autre cartographiait l'infrastructure du pouvoir : qui possède la machine, qui en tient les fils. Le dernier cherchait une sortie, traçait un archipel, et finissait sur une lettre, écrite d'ailleurs, qui ne disait qu'une chose : sortir était possible.

Ce texte-ci, je ne l'ai pas écrit pour vous. Les trois autres non plus. Il fallait que je les écrive, et que je passe par eux, pour comprendre — et pour ne pas oublier. On oublie. On tient une chose un soir, le lendemain elle s'est défaite : l'IA, le pouvoir, le simulacre, des morceaux qui ne tiennent plus ensemble. Un corpus hétérogène. Et un savoir en morceaux ne défend personne — on déplace sans effort quelqu'un dont la pensée n'a pas de colonne. C'est même ainsi qu'on déplace les gens.

Alors j'ai relié ce que je savais. C'est ce qu'on appelait Focus : relier ce qu'on a séparé, en commençant par soi. Avant de relier le dîner à la courbe, le confort à la dépossession, on relie ses propres fragments. Ce n'est pas un manifeste, c'est une mise en ordre. Faites la vôtre. Pas la mienne — la vôtre. Prendre le temps de structurer sa pensée sur ces questions, c'est déjà cesser d'être un simple usager ; tout part de là. Ce qui suit est ma mise en ordre : servez-vous-en comme d'un échafaudage.

---

## Préface  <!-- à écrire : le pacte ; le geste, pas la thèse -->

---

## Bifurcation I — Le Corps · *peser le nuage*  <!-- DESCENTE — à écrire -->

<!-- Seuil rédigé, À RE-TONER (couper « on avait / prenez » façon aparté ; durcir) : -->
<!--
On avait inventé une startup qui n'existait pas. Re.Next : une parodie d'entreprise accélérationniste, montée pour voir le système de l'intérieur. […] full gas in neutral. Toute l'énergie, aucun déplacement, et au bout, une seule chose produite : de la chaleur. […] On nous a vendu un nuage. C'est une mine, une centrale, une nappe qu'on vide. […] Le deuxième principe de la thermodynamique est le vrai futur antérieur : ce qui aura été dissipé ne se redissipe pas. […] Ce corps a deux métabolismes. On n'en montrera d'abord qu'un.
-->

- **I.1 L'apesanteur vendue** —
- **I.2 La boucle qui se mord** —
- **I.3 L'auto-intoxication** —
- **I.4 Le laboratoire** —
- **I.5 Ce que la boucle brûle** —
- **I.6 La géographie du substrat** —
- **I.7 Le fond : la facture** —

---

## Bifurcation II — Le Faux Ciel · *fuir sans sortir*  <!-- MONTÉE QUI ÉCHOUE — à écrire -->

- **II.1 Deux portes** —
- **II.2 Le mur de l'État** —
- **II.3 Le faux ciel** —
- **II.4 Pourquoi le ciel ne refroidit pas** —
- **II.5 Le dépassement promis** —
- **II.6 Ce qui fait tenir** —  <!-- sacralisation [À VÉRIFIER] -->
- **II.7 Le dehors est inéliminable** —  <!-- payoff / charnière -->

---

## Bifurcation III — Le Retournement · *ni en haut ni ailleurs*  <!-- RETOURNEMENT — à écrire — LIGNE ROUGE SERRÉE -->

- **III.1 Ni en haut ni ailleurs** —
- **III.2 Où est le contrôle** —
- **III.3 Rendre révocable** —
- **III.4 Défaire l'oracle** —
- **III.5 À quel tempo** —  <!-- FIGURE STRICTE : jamais protocole -->
- **III.6 Ne plus être usager** —

---

## Bifurcation IV — Le Foyer · *rallumer l'âtre*  <!-- CONSTRUCTION — à écrire -->

- **IV.1 La provenance contre la puissance** —
- **IV.2 Le petit modèle est un témoin** —
- **IV.3 Magnifier une graine** —
- **IV.4 La forme suit le flux** —
- **IV.5 Le pôle remède** —
- **IV.6 Le critère est physique** —  <!-- payoff -->

---

## Coda — Ce qui aura été · *la chaleur rendue*  <!-- ATTESTATION — à écrire ; Arche peut signer (option) -->
