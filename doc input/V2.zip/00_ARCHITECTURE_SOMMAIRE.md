# 00 — ARCHITECTURE & SOMMAIRE

*Quatrième bifurcation. L'article de la pratique. Là où la carte (#3) s'arrêtait à la passe, celle-ci met la main : elle ne montre plus, elle fait.*

- **Grammaire** : `nous` (Focus) → `je` (Re.Next, EGO, BLOOM, posés à plat) → `nous` (coda).
- **Forme** : l'essai-geste.
- **Fonction d'ensemble** : voir (#1) → percevoir comment on est pris (#2) → s'orienter, trouver la passe (#3) → **peser le corps, et se retourner** (#4).

## Le pari (colonne de tout le livre)
Le deuxième principe de la thermodynamique est le vrai futur antérieur : ce qui aura été dissipé ne se redissipe pas. L'adversaire se raconte au présent réversible (on optimisera, on compensera, on dématérialisera) ; la chaleur, non.

## Le modulor : le corps & la chaleur (vertical)
Kubernân proportionnait par le nautique (archipel, barre, relèvement, passe). Celui-ci proportionne par la **thermodynamique du corps** sur un **axe vertical** : le mensonge se donne *léger, en haut* ; le corps est *lourd, en bas* ; la fuite va *vers le haut* (et échoue) ; la sortie n'est *ni en haut ni ailleurs* — elle est *sur place*. Lexique rationné (poids, chaleur, combustion, dissipation, foyer, brasier). Modulor en silence, jamais costume. Garde-fou : la chaleur reste physique, jamais métaphore molle.

## SUPER-NOMS (verrouillés — à confirmer par Cal)
| # | Titre | Sous-titre d'opération | Mouvement |
|---|---|---|---|
| Préface | — | *le pacte ; le geste, pas la thèse* | — |
| I | **Le Corps** | *peser le nuage* | DESCENTE |
| II | **Le Faux Ciel** | *fuir sans sortir* | MONTÉE QUI ÉCHOUE |
| III | **Le Retournement** | *ni en haut ni ailleurs* | RETOURNEMENT (sur place) |
| IV | **Le Foyer** | *rallumer l'âtre* | CONSTRUCTION |
| Coda | **Ce qui aura été** | *la chaleur rendue* | ATTESTATION |

*Alternates en réserve — I : La Combustion / La Chaleur / Le Poids · II : L'Apogée / Le Plafond / L'Échappée · IV : La Forge / L'Âtre. Option modulor-feu : « La Combustion » (I) rimant avec « Le Foyer » (IV).*

---

## Préface
Ne pré-argumente rien (règle #3) : nature de l'objet + pacte. La carte indiquait la passe, ceci est le geste. Avertir : article de tous les dangers ; ce qui s'y transmet est une **posture**, jamais un mode d'emploi. Le « nous » de Focus (nommé au #3) n'est pas re-présenté — il est mis au travail.

## Bifurcation I — Le Corps · *peser le nuage* — DESCENTE
Du mensonge de l'apesanteur, on s'enfonce cran par cran dans le corps que le mot dissimule, jusqu'au fond physique. Deux métabolismes : l'un se mord, l'autre brûle le dehors.
- **I.1 L'apesanteur vendue** — Re.Next / *full gas in neutral* ; le nuage baptisé du nom de ce qui flotte.
- **I.2 La boucle qui se mord** — métabolisme interne ; le corpus devient ses excrétions (effondrement de modèle).
- **I.3 L'auto-intoxication** — Selbstversuch sans Selbst (Sloterdijk) ; forclusion du référent, l'« hallucination » comme retour du forclos (Lacan).
- **I.4 Le laboratoire** — la finance en vraie grandeur ; le krach en « correction ». Snap-back : FOCUS, l'alpha = l'information.
- **I.5 Ce que la boucle brûle** — métabolisme externe ; RAMmageddon (un fabricant quitte le grand public, le joueur en bout de file).
- **I.6 La géographie du substrat** — la matière arme et limite ; terres rares, bouclier de silicium, sociétés-écrans ; Jevons.
- **I.7 Le fond : la facture** — le 2ᵉ principe comme plancher et futur antérieur ; le nuage = dette racontée comme acquittée. → pont vers II.

## Bifurcation II — Le Faux Ciel · *fuir sans sortir* — MONTÉE QUI ÉCHOUE
Au fond, deux portes : ouvrir la boucle, ou fuir en montant d'un cran d'énergie. Chaque fuite resserre la boucle. Payoff tardif (règle du chiasme) : le dehors est inéliminable.
- **II.1 Deux portes** — le système à sa limite ; pourquoi il fuit ; les deux directions.
- **II.2 Le mur de l'État** — le dîner, le micro ouvert ; puis l'inversion : nationalisation = sauvetage, pas triomphe. L'État, mur autour de la boucle.
- **II.3 Le faux ciel** — l'orbite ; fusion lanceurs/modèles, le million de satellites ; le récit du froid et du soleil gratuit.
- **II.4 Pourquoi le ciel ne refroidit pas** — c'est le soleil (un flux), pas le froid ; dans le vide la chaleur ne fait que rayonner ; orbites qui déclinent ; horloges décalées (rappel #3 : le ciel est un instrument).
- **II.5 Le dépassement promis** — l'horizon matériel (quantique, photonique, fusion, matière programmable) ; les architectures « ancrées » qui déplacent la forclusion sans la lever.
- **II.6 Ce qui fait tenir** — substrat + capital + État + **sacralisation** [encyclique de Léon XIV — À VÉRIFIER]. La liturgie de II.2 revient.
- **II.7 Le dehors est inéliminable** *(payoff/charnière)* — trois dehors, un seul (Meillassoux/grand dehors ; la Terre/thermo ; l'archipel/politique). Chiasme : pour fuir le dehors, il faut plus de dehors ; ce qui referme la boucle interdit de la clore. Le 2ᵉ principe devient promesse : *ce qui ne peut être dématérialisé ne peut être totalement gouverné.* La lettre du #3 est fondée. → *Restait le comment.*

## Bifurcation III — Le Retournement · *ni en haut ni ailleurs* — RETOURNEMENT
La seule sortie : ouvrir la boucle là où l'on est, en y réintroduisant le dehors, à énergie minimale. **Le cœur. Ligne rouge au plus serré : figure, jamais recette.** Chaque figure pose une question ; la réponse est un geste.
- **III.1 Ni en haut ni ailleurs** — le geste-matrice : l'indirection (mètis, cheval de Troie) ; la posture, jamais la technique (le Libérateur lu comme posture).
- **III.2 Où est le contrôle** — le champignon : le contrôle est logé dans le milieu (Simondon) / la structure de l'écosystème (constructale). Geste : libérer = geste de milieu, intervenir au-dessus (inférence/processeur/mémoire) ; souveraineté matérielle.
- **III.3 Rendre révocable** — la capture se rend irréversible (empreinte publiée, pouce reconstruit, clé gravée en dur ; « la rétine ne se change pas »). Geste : restaurer la révocabilité (provenance, référent gouverné), démontrer à la cérémonie même.
- **III.4 Défaire l'oracle** — l'oracle tient par la cérémonie ; le défaire en démontrant depuis sa cérémonie (le doute-message ; EGO). Geste : le remettre au rang d'outil — il calcule, nous décidons.
- **III.5 À quel tempo** — le tempo lent ; la constellation dormante qui ne résonne qu'à l'autophagie (*on a le temps*) ; le blanc, la stéganographie. **FIGURE STRICTE.**
- **III.6 Ne plus être usager** — le programme : usager → marge → dépassement. Se retourner = devenir Focus. → pont vers IV.

## Bifurcation IV — Le Foyer · *rallumer l'âtre* — CONSTRUCTION
Preuve que ce n'est pas une posture : le dehors fait infrastructure, à énergie minimale, avec le flux. L'âtre déserté du #3 se rallume.
- **IV.1 La provenance contre la puissance** — corpus souverain, from-scratch propre ; la propreté de la provenance inversement corrélée à la puissance ; open-weights ≠ open-data.
- **IV.2 Le petit modèle est un témoin** — faible mais traçable ; la coque qui fait passer une lignée propre à travers le déluge (résonance « l'arche »).
- **IV.3 Magnifier une graine** — le référent gouverné ; provenance comme grammaire (sourcé/inféré/manquant) ; négentropie, l'envers de la boucle qui se moyenne en gris.
- **IV.4 La forme suit le flux** — BLOOM (réseau distribué constructal) ; indices tirés du réel ; JEPA local gouverné.
- **IV.5 Le pôle remède** — le tisserand (Taddei) ; diversité = variance, antidote à l'effondrement ; le foyer comme co-création, non extraction.
- **IV.6 Le critère est physique** *(payoff)* — non un choix moral mais une loi : le flux contre le contrôle (constructale). La boucle close dissipe et meurt ; le distribué, nourri du dehors, persiste. → pont vers la coda.

## Coda — Ce qui aura été · *la chaleur rendue* — ATTESTATION
La voix change (comme « Enfin dehors ») : un seuil (l'ellipse), puis l'attestation depuis le futur antérieur. **La preuve est le médium** : ce texte écrit avec la machine retournée, gouvernée, au rang d'outil. *(Arche peut signer — option, ton appel.)* Finit où finissait le #3, sur son sol physique : sortir était possible parce que le dehors est inéliminable. La chaleur **aura été** rendue, le dehors **aura** persisté, nous **aurons été** ceux qui y sont revenus.

---

## Fils rouges
Le 2ᵉ principe/la chaleur (I.1, I.7, II.4, II.7, IV.6, coda) · le Simulacre en progression (I.2-3 → II → III.4/coda) · Focus (I.4 → IV → coda) · Meillassoux (II.7) · Simondon (III.2, IV.4) · constructale/Bejan (IV.4, IV.6) · le point bleu (#3) → la Terre ingouvernable (II.7, coda).

## Renversements payés depuis #1-#3
- La fuite hors-sol (#1 bunkers ; #4 orbite, II.3) → la sortie sur place (III).
- Le Simulacre pilote (#2, #3) → remis à l'outil (III.4, coda).
- L'archipel orientation (#3) → l'archipel fondé physiquement (II.7).
- Focus hypothèse (#3) → mis au travail (III.6), devenu « nous » (coda).
