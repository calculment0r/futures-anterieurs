# README — Futures antérieurs

**Quatrième bifurcation** d'une traversée qui en compte quatre. Les trois précédentes ont vu ce qui est (#1), nommé le Simulacre (#2), orienté vers la passe (#3). Celle-ci **exécute** : c'est l'article de la pratique — et de tous les dangers, parce qu'on y explique le geste.

## Le pari
Le deuxième principe de la thermodynamique est le vrai futur antérieur : ce qui aura été dissipé ne se redissipe pas. Le titre est un temps de verbe.

## Forme & grammaire
- Forme : l'essai-geste (≠ la carte du #3). Modulor **thermodynamique et vertical** (le corps & la chaleur).
- Grammaire : `nous` (Focus) → `je` (Re.Next, EGO, BLOOM, posés à plat) → `nous` (coda).

## Carte de la doc (`doc/`)
**Pilotage**
- `CLAUDE.md` — instructions de tête de projet (point d'entrée).
- `README_PROJET.md` — ce fichier.
- `00_ARCHITECTURE_SOMMAIRE.md` — pari, modulor, 4 bifurcations, 26 sous-chapitres, super-noms.
- `01_STYLE_METHODE.md` — la voix, la méthode.
- `02_CORPUS_AUTEURS.md` — les témoins.
- `03_FIGURES.md` — les figures non nommées (faits + formulation + renvois).
- `04_GARDE_FOUS.md` — la ligne rouge, les garde-fous, le crédit, la cloison.

**Matière (par domaine, pas par chapitre)**
- `MATIERE_HACKING.md` · `MATIERE_FINANCE.md` · `MATIERE_MATERIEL_THERMO.md` · `MATIERE_POUVOIR_ETAT_ORBITE.md` · `MATIERE_REMEDE.md` · `MATIERE_ANECDOTES_JE.md` · `MATIERE_PHILO_OPERATIONS.md`

**Texte**
- `MANUSCRIT.md` — l'essai en cours (intro verrouillée + Seuil ; grandit bifurcation par bifurcation).

**Hors dossier (référencés, non copiés)** : les 3 articles précédents, repo `simulacre`.

## État d'avancement (à tenir à jour)
- Architecture : **proposée**, super-noms à confirmer par Cal.
- Intro : **verrouillée**. Seuil : rédigé, **à re-toner** (registre Kubernân).
- Bifurcations I-IV : à écrire.
- Recherche en attente : encyclique de Léon XIV (II.6) ; « teilster » (à élucider) ; chiffres exacts à revérifier au moment d'écrire.
