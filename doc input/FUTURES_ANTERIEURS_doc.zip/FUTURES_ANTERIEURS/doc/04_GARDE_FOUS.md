# 04 — GARDE-FOUS (ligne rouge)

*Cet article explique la pratique. C'est ce qui le rend fort et ce qui le rend dangereux. La règle qui suit n'est pas une précaution morale ajoutée après coup : c'est une condition de justesse. Un texte qui bascule en mode d'emploi cesse d'être ce texte.*

## 1. Figure, jamais recette — LA règle
Toutes les figures de contournement se tiennent **au niveau de la figure et de la recherche publique déjà existante**, jamais au niveau du protocole reproductible.
- **Ce qu'on fait** : nommer l'opération, montrer qu'elle existe (fait public, daté, déjà documenté), en tirer la **posture** et le sens.
- **Ce qu'on ne fait pas** : donner les paramètres, l'enchaînement, les valeurs, la marche à suivre qui permettraient de refaire.
- Zones les plus sensibles, à surveiller ligne à ligne :
  - **III.5** — la constellation dormante, le blanc, la stéganographie : **figures qui riment avec Focus**, jamais un procédé déployable. On dit *qu'*une constellation peut résonner à l'autophagie ; on ne dit pas *comment* la semer.
  - **III.3** — biométrie / clé en dur : on cite des démonstrations **publiques et anciennes** (empreinte publiée, pouce reconstruit en congrès) pour établir l'irréversibilité ; on n'outille personne.
  - **MATIERE_HACKING** — poisoning, scaling, jailbreak : on abstrait la **méthode-figure** (mètis, cheval de Troie), pas la technique. Le « Libérateur » est lu comme une **posture**, pas comme un manuel.
- Test simple avant d'écrire une phrase de la Bif. III : *est-ce que cette phrase aide à comprendre, ou est-ce qu'elle aide à faire ?* Si elle aide à faire, on la coupe ou on la remonte au niveau de la figure.

## 2. Cosmos & thermodynamique : physique, jamais mystique
La chaleur, le deuxième principe, le dehors thermodynamique restent **physiques et exacts**. Pas de métaphore molle, pas de consolation cosmique, pas de sacré de substitution. La rigueur physique EST la force de l'argument ; l'attendrir le détruit.

## 3. Crédit des idées
Les concepts et projets de Cal se posent en `je`/`on`, jamais en « trouvailles de recherche » :
- **Re.Next** (parodie/sonde, *full gas in neutral*), **EGO**, **BLOOM**, **FOCUS** (la BD, l'alpha = l'information), la **thèse** (constructale), le **doute-message**, Hosts in a Shell. → `MATIERE_ANECDOTES_JE.md`.
Les faits du monde (dîner, RAMmageddon, orbite, chip war, finance) sont, eux, de la **matière vérifiée** avec source.

## 4. Cloison NIRVALAB / Show Runner
On peut mobiliser les **concepts de provenance** (sourcé / inféré / manquant ; référent gouverné) dans l'essai **en termes généraux**. On ne traîne pas la marque NIRVALAB/Show Runner ni les autres projets (ASILE, UFC vs Zombies, Second Earth, Hit-Parade…) dans le texte, sauf si Cal les convoque explicitement.

## 5. Recherche EN ATTENTE (ne pas écrire tant que non confirmé)
- **Encyclique de Léon XIV / sacralisation par l'Église** (II.6) — à vérifier. Sinon, la sacralisation se traite sans elle (capital + État + liturgie du dîner suffisent).
- **« teilster »** — terme introuvable en recherche ; élucider avec Cal ou abandonner.
- **Chiffres exacts** (part de DRAM, nombre de satellites, pertes des laboratoires) — revérifier au moment d'écrire le passage : ce sont des ordres de grandeur datés qui bougent.

## 6. Ton (rappels qui coupent)
- Aucun « vous » qui explique. Aucun moralisme, aucune indignation affichée : **la précision tient lieu de colère**.
- Anecdote posée à plat, retournée d'une phrase froide.
- Pas de liste de piliers : **un mouvement, une direction**.
- Jamais d'émoji.
