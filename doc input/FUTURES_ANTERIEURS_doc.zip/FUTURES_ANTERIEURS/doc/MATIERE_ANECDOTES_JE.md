# MATIERE — ANECDOTES (JE)

*Les figures de Cal, posées à plat, à la première personne (`je`/`on`). Jamais en « trouvailles de recherche ». Posées comme des faits simples (« on avait inventé une startup qui n'existait pas »), retournées d'une phrase froide.*

## Re.Next (→ I.1, matrice de la Bif. III)
- **Ce que c'était** : une **parodie d'entreprise accélérationniste**, une **sonde-trickster** — pas une vraie startup. Montée pour **voir le système de l'intérieur**.
- **Le mot d'ordre** : ***full gas in neutral*** (garder en anglais). Toute l'énergie, aucun déplacement ; au bout, une seule chose produite : de la chaleur. (On n'avait pas le vocabulaire de la thermodynamique — on avait l'image. Quinze ans plus tard, elle est devenue un climat.)
- **Où elle a servi** : pitchée à **Parsons** (The New School, NYC, école de design nourrie de Deleuze) ; **citée dans une étude** sur ce que partagent **Uber et Red Bull** (la même foi dans la vitesse pure) ; utilisée pour **entrer dans les hackathons d'innovation d'État** (labos type **Orange**) et regarder la machine du dedans.
- **Origine** : **M.E.L.T** était au départ un livre sur l'entrepreneuriat visant à livrer une **méthode-trickster**.
- **Le sens (pas une confession)** : *tricher le système pour le comprendre* — la **posture** de tout ce qui suit. Le doute semé comme message.

## Le doute-message (→ III.4)
- Le geste de laisser un **doute** dans le dispositif : non un sabotage, un **message** — rappeler que la machine est un outil, pas un oracle. *Il calcule, nous décidons.*

## EGO (→ III.4)
- **Jeu vidéo** qui **rendait visible le profilage algorithmique** — donner à voir, dans le jeu, ce que le dispositif fait au joueur. Figure du « défaire l'oracle depuis sa cérémonie ».

## FOCUS (→ I.4 ; voir aussi MATIERE_FINANCE)
- **BD**, trilogie HFT (Eliott / Bruno X / Sahra ; focales constructales emboîtées ; spin-off *Black Swag* ; Métal Hurlant). Thèse : ***l'alpha n'est plus l'algo, c'est l'information.*** Motifs : la microseconde ; la foreuse dans les Appalaches ; DIGIT. *(Certains déjà au #3 — ne pas redoubler.)*

## La thèse (→ appui III.2, IV.4, IV.6)
- **« Kubernân, théorie constructale de l'information cognitive »** (Bejan, post-transformer, nombres adimensionnels cognitifs). Le socle savant de tout l'argument physique. *(Fichier source dans le Drive de Cal, pas ici.)*

## BLOOM (→ IV.4 ; voir MATIERE_REMEDE)
- Système distribué constructal de Cal (LMSS, indices du réel, JEPA local, Ouroboros). Posé comme **son** projet, `on`.

## Réservoir biographique (à doser, jamais étaler)
- ~15 ans en cinéma/animation/immersif ; ~15 ans de fréquentation de l'**accélérationnisme / Land** (réservoir critique, pas étalage) ; **re.accelerationism** présenté à Parsons (2011).
- **Aardman** (Shaun the Sheep, EMIT/EmilXR) — clin d'œil possible pour la **coda** (le côté « désuet », l'artisanat contre l'échelle).

## Question ouverte
- **« teilster »** : terme évoqué mais introuvable — à élucider avec Cal ou abandonner.

## Règle
Ces items se **montrent**, ils ne se **prouvent** pas. Une anecdote, une phrase de retournement, on avance. Aucune ne doit sonner comme un CV : *tout ce qui sonne comme un CV se coupe.*
