# 03 — FIGURES (non nommées mais identifiables)

*Méthode #1 : on ne nomme pas les actants. On donne les faits exacts et l'on laisse reconnaître. La reconnaissance fait le travail que le nom ferait, en mieux — elle implique le lecteur. Un à deux actants par chapitre, froids, factuels. Les penseurs, eux, se nomment (voir `02_CORPUS_AUTEURS.md`).*

## Convention
- Formuler par la fonction et le fait, jamais par le nom : « un président qui a lancé une pièce à son nom », « une île qui fabrique ce que personne d'autre ne sait faire ».
- Donner **un** fait vérifiable et daté (voir la source dans le `MATIERE_*` correspondant). Ne jamais empiler les détails : un suffit à faire reconnaître.
- Ton froid, aucune indignation. La figure est un **mécanisme**, pas un scandale.

## Répertoire (→ sous-chapitre)

**Bif. II — Le Faux Ciel**
- *Le dîner et le micro ouvert* — un dîner d'automne à la présidence, des centaines de milliards d'investissement promis, un micro resté ouvert qui capte la liturgie de l'allégeance. → **II.2**. (Source : MATIERE_POUVOIR.)
- *Le dirigeant qui prédit la nationalisation* — le patron d'un groupe de logiciel-renseignement annonce une nationalisation complète à brève échéance ; des prises de participation publiques sont évoquées. → **II.2**. Retournement froid : on ne nationalise pas des triomphes.
- *La fusion des lanceurs et des modèles* — on fond la société qui lance les fusées et celle qui fait les modèles ; on dépose pour des constellations de centres de calcul, jusqu'au million de satellites. → **II.3**. (Source : MATIERE_POUVOIR / MATERIEL.)
- *Le clocher qui bénit* — [À VÉRIFIER] une parole d'Église qui sacralise la machine (encyclique de Léon XIV). → **II.6**. Ne pas écrire tant que non confirmé.

**Bif. I — Le Corps**
- *Le fabricant qui quitte le grand public* — un fabricant de mémoire abandonne le marché grand public pour réserver ses lignes aux centres de calcul ; le joueur se retrouve en bout de file. → **I.5**. (Source : MATIERE_MATERIEL.)
- *L'île bouclier de silicium* — une île fabrique les puces fines que nul autre ne sait faire ; elle en devient un enjeu de guerre. → **I.6**.
- *Les sociétés-écrans* — on fait fabriquer, via des sociétés interposées, chez le fondeur qu'on n'a pas le droit d'employer, des millions de galettes destinées à l'ennemi désigné. → **I.6**.
- *Le régulateur qui parle de troupeau* — une autorité de stabilité financière s'inquiète de l'homogénéisation, du comportement grégaire, de la corrélation qui monte. → **I.4** (non attribué ou à peine). (Source : MATIERE_FINANCE.)

**Bif. III — Le Retournement** *(figures = faits publics, jamais protocole — voir 04_GARDE_FOUS)*
- *Le ministre dont on a publié l'empreinte* — l'empreinte digitale d'un ministre reproduite et diffusée à partir de documents publics. → **III.3**.
- *La dirigeante au pouce reconstruit* — le pouce d'une dirigeante reconstitué à partir de simples photos de presse, démontré lors d'un congrès. → **III.3**. (Source : MATIERE_HACKING.)
- *La clé gravée en dur* — des clés de sécurité inscrites dans le silicium, non révocables : une fois extraites, catastrophiques et définitives. → **III.3**.

## Figures « je » (posées à plat, à la première personne)
Re.Next · EGO · le doute-message · la thèse · BLOOM · FOCUS. Ce ne sont pas des figures à faire reconnaître : ce sont les siennes, posées directement (« on avait inventé une startup qui n'existait pas »). Voir `MATIERE_ANECDOTES_JE.md`.
