# MATIERE — POUVOIR / ÉTAT / ORBITE (les faux dehors)

*Colonne de la Bif. II. Les deux fuites de l'adversaire pour rester fermé en montant d'un cran : vers l'État, vers l'orbite. Plus ce qui les fait tenir.*

## Le mur de l'État (→ II.2)
- **Le dîner** : dîner à la Maison-Blanche (4 sept. 2025), président + patrons de la tech ; « 600 Mds+ d'ici 2028 » ; **micro resté ouvert** captant la liturgie de l'allégeance (chacun récite son chiffre). Lecture immédiate : triomphe de l'industrie.
- **L'inversion** : début juin 2026, le président évoque des **prises de participation de l'État** dans OpenAI / Anthropic / xAI ; **Karp (Palantir)** prédit une **nationalisation complète sous ~2 ans**. **Bannon** (War Room) pousse ; **Vance** en soutien.
- **Le retournement froid** : on ne nationalise pas des triomphes. **OpenAI** ~14 Mds de pertes (2026) ; **xAI** a perdu ~6,4 Mds sur ~3,2 Mds de revenus (2025) ; **Anthropic** ~47 Mds de run-rate, approchant la rentabilité. → *la nationalisation est un **sauvetage**, pas une conquête ; l'État devient le **mur** autour de la boucle pour qu'elle tourne sans s'ouvrir.*
- Contexte utile : **Musk** a quitté l'administration le 30 mai 2025 et était en **guerre ouverte** avec le président **avant** le dîner de septembre.

## Le faux ciel (→ II.3-II.4)
- **Orbite** : **SpaceX–xAI fusionnés** (2 fév. 2026) ; dépôt **FCC** jusqu'à **1 M de satellites-datacenters** ; **Suncatcher** (satellites à TPU, horizon 2027) ; échos **ESA ASCEND**, imaginaire *Three-Body*.
- **Le récit** : là-haut, froid + soleil gratuit = dehors infini.
- **La correction** (physique, → renvoi MATIERE_MATERIEL_THERMO) : c'est le **soleil** (un flux), pas le froid ; **le vide ne refroidit pas** (rayonnement lent) ; **orbites qui déclinent** ; **horloges décalées**. → *l'orbite = la même boucle, plus haut, plus cher.*

## Le dépassement promis (→ II.5)
- La fuite en avant : horizon matériel (photonique, quantique, fusion, matière programmable — voir MATERIEL) ; et les architectures qui prétendent **s'ancrer dans le monde** (world-models, JEPA côté adversaire) tout en restant ancrées **sur ce qu'elles contrôlent** — la **forclusion déplacée**, non levée.

## Ce qui fait tenir la fuite en l'air (→ II.6)
- **Substrat** (les puces, MATERIEL) + **capital** (le sauvetage permanent) + **État** (le mur) + **sacralisation**.
- **Sacralisation** — **[À VÉRIFIER]** : une parole d'Église qui bénit la machine (**encyclique de Léon XIV** ; opération de type « Anthropic au Pape »). **Ne pas écrire tant que non confirmé.** À défaut, la sacralisation se dit par la **liturgie du dîner** (II.2) + le capital + l'État.

## Gouvernance (appui, → II.7 et III.3-III.4)
- **Berkman Klein** : écosystèmes agentiques largement **ingouvernables** ; nécessité d'un *root of trust*.
- **Schneier** : « la biométrie n'est pas un secret ». → nourrit III.3 (l'irréversibilité) et le pivot II.7 (ce qui ne peut être clos).

## Le pivot (→ II.7)
Les trois dehors n'en font qu'un : **grand dehors** (Meillassoux) / **thermodynamique** (Latour, la Terre) / **politique** (l'archipel, #3). Chiasme (payoff tardif) : *pour fuir le dehors, il faut plus de dehors ; ce qui referme la boucle interdit de la clore.* Le 2ᵉ principe devient **promesse** : *ce qui ne peut être dématérialisé ne peut être totalement gouverné.* → la lettre du #3 est fondée.

## Sources / à revérifier
Dîner sept. 2025 ; prises de participation juin 2026 ; Karp/Palantir ; pertes OpenAI/xAI/Anthropic ; SpaceX-xAI fév. 2026 ; FCC 1 M sats ; Suncatcher. Recherche publique 2025-2026. **Encyclique Léon XIV = à confirmer.** Revérifier chiffres au moment d'écrire.
