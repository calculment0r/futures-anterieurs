# MATIERE — FINANCE (le laboratoire grandeur nature)

*Sert surtout en **I.4** (la boucle interne, vue en vraie grandeur) ; appoints en II (nationalisation = sauvetage) et IV (le distribué persiste).*

## La thèse : presque personne ne construit de zéro
- **BloombergGPT** (50 Mds de paramètres, ~363 Mds de tokens financiers, entraîné *from scratch*) a **sous-performé** face à des modèles plus petits *finetunés* et face aux généralistes de pointe. Le from-scratch financier lourd n'a pas payé.
- Conséquence : la finance n'a **pas** construit ses propres cerveaux — elle **agrège** les modèles existants.
  - **JPMorgan** — « LLM Suite » : une **plateforme** qui agrège plusieurs modèles du marché + l'interne ; tâches de junior (synthèses, brouillons), quelques heures gagnées par semaine et par analyste.
  - **Morgan Stanley** — assistant sur base généraliste + RAG sur la doc maison.
  - **Goldman** — déploiement transverse (banque + gestion d'actifs).
  - **Buy-side** — LLM passés sur les flux : sentiment, résumés d'*earnings calls*, signaux.

## Le mécanisme autophage (le cœur de I.4)
- Mêmes modèles chez tout le monde, sur les mêmes flux → chacun lit le marché avec l'outil du voisin → chacun voit la même chose → chacun fait le même geste.
- **Le signal que tout le monde possède cesse d'être un signal.** L'avantage s'évapore en se partageant.
- **FSB** (Conseil de stabilité financière, 10 oct. 2025) : l'homogénéisation nourrit la **grégarité** (herding), la corrélation, la fragilité systémique ; dégradation de l'alpha.
- Le retournement de la position commune, quand il vient, sera raconté le lendemain en **« correction »**. → *la finance appelle krach un moment où la boucle a bouclé trop fort.*

## Le visage grand public de l'homogénéisation
- **Robinhood — Agentic Trading** (2 juin 2026) : « trade while you sleep ».
- **Trade Republic**, **copy-trading** : la monoculture rendue populaire — tout le monde suit les mêmes signaux, donc la même pente.

## Le snap-back (motif de Cal — FOCUS)
- **FOCUS** (BD, trilogie HFT) : *l'alpha n'est plus dans l'algorithme, il est dans l'information* — et quand tout le monde a la même information, traitée par la même machine, il n'y a plus d'alpha, seulement une chambre d'écho qui se cite à la microseconde.
- Réserve d'images HFT (déjà en partie au #3, à ne pas redoubler) : la microseconde ; la foreuse dans les Appalaches ; Laumonier (*6/5*).

## Pourquoi c'est LE laboratoire
La finance est le seul milieu où la boucle autophage tourne déjà **à pleine échelle, avec de l'argent réel** : un système qui ne lit plus que ses propres anticipations. Elle donne à voir, en accéléré, ce que devient tout domaine qui adopte les mêmes modèles — la **variance qui s'effondre** (lien avec IV.5, la diversité = la variance).

## Sources / à revérifier
BloombergGPT (papier public). JPMorgan LLM Suite, Morgan Stanley, Goldman (annonces publiques). FSB oct. 2025. Robinhood juin 2026. Revérifier dates/chiffres au moment d'écrire.
