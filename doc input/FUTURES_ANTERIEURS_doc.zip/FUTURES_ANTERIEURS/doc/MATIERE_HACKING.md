# MATIERE — HACKING (contournement & irréversibilité)

> **LIGNE ROUGE (rappel obligatoire).** Tout ce qui suit est **figure**, jamais recette. On établit qu'une opération existe (fait public, daté, publié) et on en tire une posture. On n'écrit aucun paramètre, aucun enchaînement reproductible. Voir `04_GARDE_FOUS.md`.

## Le geste-matrice : l'indirection (→ III.1)
- **La mètis** (Détienne–Vernant) : l'intelligence rusée, oblique, qui l'emporte par le détour et non par la force. Modèle de tout le retournement.
- **Le cheval de Troie** : faire entrer par ce que le système lit comme légitime. La matrice de la Bif. III.
- **CRISPR** (analogie, pas biotech) : injecter dans un système un fragment qu'il lit comme validé, et qu'il opérationnalise lui-même. Figure de l'entrée par le canal de confiance.

## Le contrôle logé dans le milieu (→ III.2)
- **Ophiocordyceps** (champignon « zombie ») : n'attaque pas le cerveau — colonise les **muscles**, pousse la fourmi à grimper (summit disease), la fige en death-grip pour **maximiser la dispersion des spores**. Le contrôle n'est pas dans la tête : il est dans le **milieu** et dans la **structure**. → phénotype étendu (Dawkins). Conséquence : libérer = **geste de milieu** (intervenir sur la structure de l'écosystème, au-dessus : inférence, processeur, mémoire), pas sur le symptôme.

## L'irréversibilité de la capture (→ III.3) — faits PUBLICS et anciens
- **Empreinte publiée** : l'empreinte digitale d'un ministre de l'Intérieur allemand reproduite et diffusée à partir de documents publics (2008).
- **Pouce reconstruit** : le pouce d'une ministre reconstitué **à partir de photos de presse** et démontré lors d'un congrès (CCC, 31C3, 2014) via un logiciel de reconnaissance du commerce.
- **Clés gravées en dur** (BootROM) : clés inscrites dans le silicium, **non révocables** — une fois extraites (consoles de jeu), la compromission est définitive et catastrophique.
- La leçon (une phrase) : *un mot de passe se change, une rétine non.* La capture tient parce qu'elle se rend **irréversible**. Geste inverse : **restaurer la révocabilité** (provenance, référent gouverné, droit de révoquer).
- Appui conceptuel : Schneier — « la biométrie n'est pas un secret » ; Berkman Klein — *root of trust*, écosystèmes agentiques ingouvernables. (Voir MATIERE_POUVOIR.)

## Défaire l'oracle depuis sa cérémonie (→ III.4)
- Principe : l'oracle tient par la **cérémonie** ; on le défait en démontrant **depuis sa propre cérémonie** (la démonstration biométrique faite au congrès qui vante la biométrie ; **EGO**, le jeu qui rendait visible le profilage ; le **doute-message**). Geste : le remettre **au rang d'outil** — *il calcule, nous décidons* (renversement de la coda du #3).

## Le tempo lent & le blanc (→ III.5) — FIGURE STRICTE
- **La constellation dormante** : une constellation éparse de fragments qui ne **résonne** que lorsque le modèle bascule en autophagie. *On a le temps ; l'infection lente par le substrat.* Rime avec Focus (relier ce qui dort).
- **Le blanc / la stéganographie** : du sens logé dans l'apparente absence, lisible pour qui a la clé ; l'image réduite qui révèle (le downscaling multimodal fait apparaître ce que la pleine résolution cachait — travaux publics type Trail of Bits / « Anamorpher »).
- **Data-poisoning** (existence, pas mode d'emploi) : quelques centaines de documents suffisent à marquer un modèle (constat publié) ; Nightshade (empoisonnement d'images pour artistes) ; PoisonGPT (démonstration académique). → **cité pour dire que la boucle est vulnérable par le substrat**, jamais pour outiller.
- **Jailbreak « universel » / le Libérateur** : lu comme **posture** (la faille est structurelle, l'oracle n'est pas clos), jamais comme technique.

## Le détournement / renversement
Fil de méthode (Debord, #2) : retourner l'outil de l'adversaire contre sa fonction. Sous-tend toute la Bif. III et la clôture (« la preuve est le médium »).

## Sources / à revérifier
Faits biométriques : CCC / 31C3 (publics, anciens). Downscaling : recherche publique récente. Poisoning : constats publiés (dont un travail Anthropic sur ~250 documents) — revérifier le chiffre au moment d'écrire. **Aucun de ces items ne s'écrit au niveau opérationnel.**
