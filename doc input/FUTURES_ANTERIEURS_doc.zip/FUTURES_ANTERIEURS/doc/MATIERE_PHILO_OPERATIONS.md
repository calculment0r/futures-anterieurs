# MATIERE — PHILO / OPÉRATIONS (la boîte à outils conceptuelle)

*Les gestes de pensée du texte — distincts des témoins (`02_CORPUS_AUTEURS.md`). Ici : les opérations, pas les auteurs. Peut fusionner avec 02 si Cal préfère.*

## Nommer le basculement autophage = auto-intoxication (→ I.3)
- Le geste : donner un **nom** au moment où la machine, coupée du référent, se nourrit de ses sorties. **Auto-intoxication** — ancienne doctrine médicale (le corps s'empoisonne de ses déchets), discréditée : la rappeler pour l'IA n'est pas neutre. Nuance : chez Sloterdijk, l'intoxication est **volontaire** (un doseur) ; ici, **personne ne dose** — un Selbstversuch sans Selbst.

## La forclusion du référent (→ I.2-I.3)
- Le geste : lire l'« hallucination » non comme un bug mais comme le **retour du forclos** (Lacan). Le référent nié revient dans le réel. Enchaîne avec Meillassoux (grand dehors forclos), Baudrillard (précession), Debord (spectacle), Stiegler (rétentions), Simondon (milieu perdu).

## L'analyse dimensionnelle comme méthode (→ transverse, surtout Bif. I)
- Le geste (venu de la physique) : **observer le résultat → isoler les composantes et les opérateurs → fabriquer le protocole qui explique le résultat.** Manière de démonter un dispositif par ses grandeurs plutôt que par son récit. Sous-tend la façon dont on « pèse le nuage » (Bif. I) et dont on juge par le flux (constructale, Bif. IV).

## Intervenir au niveau supérieur (→ III.2)
- Le geste : ne pas lutter au niveau du symptôme (la sortie du modèle) mais **au-dessus** — l'algorithme d'inférence, le processeur, la mémoire, le milieu. Le contrôle est **structurel** (cordyceps) ; la libération l'est aussi. Implique la **souveraineté matérielle**.

## Les deux dehors (→ charnière II.7 → III)
- Le geste : distinguer deux sorties. **La fuite vers le haut** (rester fermé à énergie plus haute : État, orbite, dépassement) — elle échoue. **Le retournement sur place** (rouvrir la boucle où l'on est, à énergie minimale) — la seule qui marche. Tout le pivot du livre tient dans cette bifurcation.

## Négentropie (→ IV.3)
- Le geste : opposer à la dissipation (2ᵉ principe subi) une **construction locale d'ordre** — magnifier une graine réelle sans halluciner. Non pas nier l'entropie (impossible) mais **travailler avec le flux** pour faire croître du réel. C'est le versant constructif du deuxième principe.

## Ne plus être usager → agir à la marge → le dépassement (→ III.6)
- Le geste-programme, en trois temps : cesser d'être **usager** (structurer sa pensée, se réapproprier l'outil) → **agir à la marge** (là où le système est ouvert, réversible) → **le dépassement** (le retournement fait infrastructure). Se retourner = **devenir Focus**.

## Le flux contre le contrôle (→ IV.6, payoff)
- Le geste final, **physique et non moral** (Bejan) : ce qui laisse mieux passer le flux persiste ; ce qui l'entrave dissipe. Le distribué dure, la capture meurt. C'est la loi qui fonde l'espoir sans le rendre moral.

## Détournement / renversement (transverse)
- Le geste de méthode (Debord, #2) : retourner l'outil de l'adversaire contre sa fonction. Aboutit à la clôture : **la preuve est le médium** — ce texte écrit avec la machine retournée.
