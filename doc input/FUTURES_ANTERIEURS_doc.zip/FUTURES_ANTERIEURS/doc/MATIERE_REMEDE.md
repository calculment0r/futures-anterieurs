# MATIERE — REMÈDE (le dehors construit)

*Colonne de la Bif. IV. Preuve que le retournement n'est pas une posture : le dehors fait infrastructure, à énergie minimale, avec le flux. Critère **physique**, non moral.*

## La provenance contre la puissance (→ IV.1)
- **Corpus souverain / from-scratch propre** : construire à partir de données entièrement traçables.
  - **Pleias / Common Corpus** : très grand corpus ouvert et tracé (ordre du millier de milliards de tokens, domaine public/licences claires).
  - **KL3M** : modèle certifié **sans matériel sous copyright**.
- **Loi de tension** (motif de Cal) : *la propreté de la provenance est **inversement corrélée** à la puissance.* On n'aura pas le plus gros ; on aura le **propre**.
- Distinction clé : **open-weights ≠ open-data.** Des poids ouverts ne disent rien de la provenance des données.

## Le petit modèle est un témoin (→ IV.2)
- Faible mais **traçable** : il ne domine pas, il **atteste**. C'est la **coque qui fait passer une lignée propre à travers le déluge autophage** — *(résonance « l'arche » ; ne pas forcément nommer Arche)*. Contre l'effondrement de modèle (I.2), un point d'origine non contaminé.

## Magnifier une graine (→ IV.3)
- **Référent gouverné** : la **provenance comme grammaire** — *sourcé / inféré / manquant* (en termes généraux, sans marque). On sait toujours d'où vient ce qu'on montre.
- **Négentropie** : magnifier une graine (une donnée réelle, tracée) **sans halluciner** — l'exact **envers** de la boucle qui se moyenne en gris. Au lieu de dissiper, faire croître le réel.

## La forme suit le flux (→ IV.4)
- **BLOOM** (système de Cal) : **réseau distribué constructal** — la forme émerge des flux (Bejan), pas d'un centre.
  - Se nourrit d'**indices tirés du réel** (capteurs, signaux du monde), **pas** de ses propres sorties.
  - **JEPA local, gouverné** (inférence pair-à-pair, 15 M évoqués) ; boucle **Ouroboros** d'auto-évolution ; familles d'indices ancrées dans le réel.
- Opposition structurante : le distribué **se nourrit du dehors** ; la capture se nourrit d'elle-même.

## Le pôle remède (→ IV.5)
- **Taddei / Learning Planet Institute** : le **tisserand**, la **maïeutique**/co-création, *best for the world, not best in the world* ; **la diversité = la variance**, antidote direct à l'effondrement (lien I.4/finance : variance qui s'effondre). Le foyer comme lieu de **co-création**, non d'extraction.

## Le critère est physique (→ IV.6, payoff)
- **Loi constructale** : ce qui laisse mieux passer le flux **persiste** ; ce qui l'entrave **dissipe et meurt**. Donc : la boucle close (capture) dissipe et meurt ; le **distribué**, nourri du dehors, **persiste**. *Le retournement n'est pas un espoir — c'est le côté de la physique qui dure.*
- Souveraineté matérielle (lien MATERIEL) : Hosts in a Shell / dual DGX — tenir son propre calcul.

## Sources / à revérifier
Pleias/Common Corpus, KL3M : projets publics (revérifier volumes/licences). BLOOM, JEPA local, Ouroboros, Hosts in a Shell = matière de Cal (`je`/`on`, jamais « recherche »). Taddei/Learning Planet : public (manifeste avec Luksha, avr. 2025).
