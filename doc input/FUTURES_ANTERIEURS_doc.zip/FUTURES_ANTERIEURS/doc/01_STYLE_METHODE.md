# 01 — STYLE & MÉTHODE

*Dérivé du STYLE_METHODE de Kubernân (#3), adapté à l'article de la pratique. Non négociable : c'est ici que se joue le ton que Cal a validé sur le #3 et refusé sur le premier jet du #4 (« trop familier et niais »).*

## Voix
- **« Nous » de Focus** : collectif partisan à venir, poreux (le lecteur qui voit y entre seul). Ni le « nous » de l'auteur, ni celui de l'humanité en général.
- Froid, déclaratif, **un cran plus Tiqqun que neutre** — mais lucide et lisible, jamais obscur.
- Mépris lucide + intimité conspirative. **Aucun moralisme** : pas de « vous » qui sermonne, pas d'indignation, **pas d'aparté au lecteur** (« prenez la mémoire », « et l'on objectera » → bannis). La précision tient lieu de colère (modèle Bruno Iksil).
- Clausule courte qui coupe. Plant / payoff.
- Jamais d'émoji. Français.

## Ce qui a tué le premier jet (à ne pas refaire)
1. Les apartés et la gentillesse au lecteur. Kubernân **ne s'adresse pas pour expliquer** ; il énonce.
2. Le **catalogue** : 8 mouvements parallèles, une liste de piliers. Faux. → méthode de fond ci-dessous.
3. Trop court. → longueur ci-dessous.

## Méthode de fond *(validée sur le #3 : « bcp mieux »)*
- **Pas de listes parallèles de « piliers »** (faible ; l'adhésion souffre ; ça paraît lacunaire). **Démontrer une seule opération qui se propage comme un mouvement** : descente, fermeture-réouverture, ascension, retournement, construction, séquence. Un mouvement réclame une **direction**, pas un catalogue — ce qui désamorce le « est-ce que c'est tout ? ».
- **Convocation dense et tissée** ; fils rouges récurrents (un penseur peut revenir éclairer plusieurs facettes — c'est voulu). **Témoins, pas autorités.**
- **Figures façon #1 : non nommées mais identifiables.** Donner les faits exacts, laisser le lecteur reconnaître. Cela enacte Focus. **Une à deux figures par chapitre** (froides, factuelles).
- **Exemples du réel placés pour aérer** : alterner concret/abstrait, casser le rythme des passages denses. Ce sont eux qui font respirer.
- **Anecdotes anodines** : posées à plat, puis retournées d'une phrase froide. Elles montrent qu'il faut être Focus pour voir (« ce n'est pas un dîner, c'est un mécanisme »).
- **Le Simulacre revient en progression** (dosage variable) : destination du détachement → faux dehors → outil remis à sa place (coda). ~2 à 4 retours par chapitre, jamais saturer, à chaque fois un emploi neuf.

## Le modulor (#4) = thermodynamique & vertical, pas costume
- Le corps & la chaleur proportionnent en silence ; lexique **rationné** (poids, chaleur, combustion, dissipation, foyer, brasier, rayonnement), là où il porte. Jamais omniprésent. Une bifurcation peut être presque sans lexique thermo tandis que son titre l'est.
- Axe vertical : *léger/en haut* (le mensonge) ↔ *lourd/en bas* (le corps) ↔ *fuite en haut* (II) ↔ *sur place* (III) ↔ *l'âtre* (IV).
- Mots-maîtres retournés de l'adversaire : **léger/apesanteur, dépassement, dématérialiser** — retournés par le poids et la chaleur.

## Garde-fous de ton
- **Thermo/cosmos froid et physique** — dissipation, rayonnement, relativité, structures dissipatives, Meillassoux. **Jamais mystique**, jamais consolation/prière.
- **Préface** : ne pré-argumente rien. Hors de l'argument — nature de l'objet (un geste, pas un traité), pacte de lecture. Le pari, le chiasme et les payoffs sont **retenus pour le corps**.
- **Le chiasme est un payoff, pas une prémisse** : il tombe en II.7 (« pour fuir le dehors il faut plus de dehors »).

## Structure d'un chapitre
Intro (le mouvement annoncé + désamorçage si utile : « nous ne dresserons pas la liste… nous suivrons une seule chose ») → sous-sections (le mouvement déroulé, figures/exemples/anecdotes ; **connecteurs de mouvement** entre elles : « descendons d'un cran », « plus bas encore », « plus haut », « retournons-nous », « avec le flux ») → **conclusion-pont (~450-480 mots)** qui referme et ouvre la bifurcation suivante, sur une question.

## Longueur
Cible minimale : **2 500-2 700 mots/bifurcation**. Option objet-livre : **4 000-5 000** (plus de scènes, plus de figures) — sans jamais trahir la froideur ni saturer.

## Crédit
- Les œuvres et idées de Cal se posent en `je`/`on`, à plat : Re.Next, EGO, BLOOM, FOCUS, la thèse, *full gas in neutral*, le doute-message, la constellation. **Jamais en « trouvailles de recherche ».**
- Le dîner du memecoin et la preuve de travail (énergie brûlée pour valider des nombres) appartiennent **déjà au #3** (I.3) — **ne pas les réutiliser** au #4 ; prendre des figures neuves pour le métabolisme interne (effondrement de modèle, monoculture financière, krach-correction).
