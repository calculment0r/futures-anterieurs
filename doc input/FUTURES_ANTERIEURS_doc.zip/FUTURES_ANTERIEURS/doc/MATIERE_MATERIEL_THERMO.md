# MATIERE — MATÉRIEL / THERMO (le substrat, la chaleur, la limite)

*Colonne de la Bif. I (le métabolisme externe, I.5-I.7) et de la physique de la Bif. II (II.4, pourquoi le ciel ne refroidit pas). Fond de tout : le corps est lourd, chaud, assoiffé.*

## RAMmageddon — la matière mange l'immatériel (→ I.5)
- Les grands centres de calcul absorbent une part massive de la production mondiale de puces mémoire (projet « Stargate » : de l'ordre de ~40 % de la DRAM mondiale, ~900 k wafers/mois évoqués).
- **Prix DRAM** : envolée vertigineuse sur 2025 (ordre de grandeur cité : +172 %) ; **SK Hynix** en rupture / vendu pour 2026 ; **Micron** se retire du grand public (marque Crucial, fév. 2026) pour réserver ses lignes aux centres de calcul ; **TrendForce** anticipait +50-55 % au T1 2026.
- Effet visible : **étranglement des GPU grand public** ; le joueur, le petit atelier se retrouvent en bout d'une file dont la tête a été rachetée. *La rareté n'est pas un accident : c'est le deuxième métabolisme qui mange le premier.*

## Jevons — l'efficacité n'éteint rien (→ I.6)
- **Paradoxe de Jevons** (deux siècles) : rendre une ressource plus efficace **augmente** sa consommation totale (chaque gain ouvre un usage de plus). « TurboQuant » / gains d'efficacité IA → effet rebond, pas sobriété. *La machine plus sobre n'éteint pas la centrale ; elle en fait construire une autre.*

## La guerre des puces — la matière comme arme ET limite (→ I.6)
- **TSMC** stoppe le 7 nm et au-delà vers la Chine (nov. 2024) ; licences **H20/H200** au compte-gouttes ; **BIS** au cas par cas (janv. 2026).
- **Terres rares** : contrôles chinois effectif 1er déc. 2025 ; **règle des 0,1 %** (un produit contenant une fraction de pour-cent tombe sous l'embargo).
- **Taïwan = « bouclier de silicium »** (pas « protectorat ») : l'île fabrique ce que nul autre ne sait faire → enjeu de guerre.
- **Contournement** : Huawei a trompé TSMC via des **sociétés-écrans** pour ~2 M de chiplets Ascend 910.
- Leçon : *l'immatériel a un substrat, et le substrat est rare, situé, disputé. On ne se bat pas pour un nuage — pour une mine et une usine.*

## Le deuxième principe — le fond (→ I.7, II.4, IV.6, coda)
- **Futur antérieur physique** : ce qui **aura été** dissipé ne se redissipe pas ; l'eau bue ne se reboit pas ; le minerai dispersé ne se recompose pas. Le nuage = **dette tirée sur le dehors, racontée comme acquittée**.
- **Physique de l'orbite** (contre le récit du froid gratuit, → II.4) : ce qui alimente là-haut, c'est le **soleil** (un flux continu à capter), pas le froid ; **le vide ne refroidit pas** — la chaleur ne peut que **rayonner**, lentement, faute de matière pour l'emporter ; **les orbites déclinent** (il faut les relever) ; **les horloges se décalent** en microgravité (rappel #3 : le ciel est un instrument, pas un refuge).

## L'horizon matériel promis (→ II.5)
- Fuite en avant technologique : **photonique**, **quantique**, **matière programmable**, **code ambiant**, **swarms de micro-calculateurs**. À traiter comme des **portes qui restent closes** (elles déplacent la limite, ne la suppriment pas), pas comme des solutions.

## Souveraineté matérielle (→ III.2, IV)
- Intervenir **au niveau supérieur** : l'algorithme d'inférence, le processeur, la mémoire. Qui tient le hardware tient le calcul — *le calcul d'un modèle peut être empoisonné sur le hardware d'un tiers*. D'où : **maîtriser son propre hardware** (Hosts in a Shell, dual DGX). Lien avec MATIERE_REMEDE.

## Sources / à revérifier
Stargate/DRAM, prix, SK Hynix, Micron/Crucial, TrendForce, TSMC/BIS/H20-H200, terres rares/0,1 %, Huawei/TSMC : recherche publique 2025-2026. **Revérifier tous les chiffres au moment d'écrire** (ordres de grandeur datés).
