# 02 — CORPUS AUTEURS

*Des témoins, pas des autorités. On ne cite pas pour s'autoriser ; on convoque une thèse là où elle éclaire un geste. Jamais d'appareil, jamais de note de bas de page dans le texte : la pensée est absorbée, reformulée, portée.*

## Le socle (récurrents)
- **Meillassoux** — le *grand dehors*, le réel antérieur à toute pensée, irréductible à notre corrélation avec lui. → **II.7** (premier des trois dehors) ; fond de la coda.
- **Simondon** — le *milieu associé*, l'individuation par le milieu. Le contrôle et la libération se jouent dans le milieu, pas dans l'individu isolé. → **III.2** (où est le contrôle) ; **IV.4** (la forme émerge du milieu).
- **Bejan / loi constructale** — *la forme suit le flux* ; ce qui laisse mieux passer le flux persiste. Critère **physique** de la sortie, non moral. → **IV.4, IV.6** ; substrat théorique de la thèse de Cal.
- **Latour** — Gaïa, le terrestre, la Terre comme puissance qui répond ; le *dehors thermodynamique*. → **II.7** (deuxième dehors) ; fond de tout le métabolisme externe (Bif. I-II).
- **Sloterdijk** — l'*auto-intoxication* / le Selbstversuch (l'auto-expérimentation), l'immunologie, les sphères. La boucle qui se dose sans doseur. → **I.3**.
- **Lacan** — la *forclusion* : ce qui est forclos fait retour dans le réel. L'« hallucination » comme retour du référent nié. → **I.3**.

## Le fil du Simulacre (dosé, en progression)
- **Debord** — le spectacle, le renversement/détournement. Fil forgé au #2 ; ici en arrière-plan. → I.2-3, III.4.
- **Baudrillard** — la *précession des simulacres*, la carte qui précède le territoire, le référent forclos. → I.2 ; charnière conceptuelle du métabolisme interne.
- **Stiegler** — le *pharmakon* (remède/poison), les rétentions tertiaires, la prolétarisation du savoir. → I.2-3 (poison) ; IV (remède) ; « ne plus être usager » (III.6).

## En appoint (ponctuels, si le passage le demande)
- **Anders** — l'*obsolescence de l'homme*, la honte prométhéenne, le décalage entre ce qu'on fabrique et ce qu'on se représente. → I.1 (le mensonge de l'apesanteur), II (la démesure).
- **Polanyi** — le *désencastrement* de l'économie hors du social. Modèle du détachement du référent hors de son sol. → I.2 (par analogie), II.
- **Tiqqun / Comité invisible** — non une thèse mais le **registre** : l'imperceptible, la sécession, la forme-de-vie, la précision froide. Modèle de voix, pas de citation.
- **Glissant** — l'*archipel*, le Tout-Monde, la relation. Déjà porteur au #3 ; ici seulement en rappel (II.7, coda) si besoin.

## Règle d'emploi
Un témoin par idée, là où il tranche. Ne pas empiler. Ne jamais nommer pour impressionner : si la thèse peut être portée sans le nom, on porte sans le nom. Les noms propres de **penseurs** sont admis (ce sont des témoins) ; les noms propres d'**actants** (dirigeants, entreprises) ne le sont pas — voir `03_FIGURES.md`.
